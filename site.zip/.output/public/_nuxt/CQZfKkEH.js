import{ax as o,ay as a,az as r}from"./CXSF_dnm.js";function c(){r({variableName:a("scrollbar.width").name})}function s(){o({variableName:a("scrollbar.width").name})}export{c as b,s as u};
