import{az as o,aA as a,aB as r}from"./D5VEO_8d.js";function c(){r({variableName:a("scrollbar.width").name})}function s(){o({variableName:a("scrollbar.width").name})}export{c as b,s as u};
