import{aM as o,aN as a,aO as r}from"./CuMfoPmn.js";function c(){r({variableName:a("scrollbar.width").name})}function s(){o({variableName:a("scrollbar.width").name})}export{c as b,s as u};
