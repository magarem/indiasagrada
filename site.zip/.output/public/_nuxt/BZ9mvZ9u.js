import{_ as e}from"./DlAUqK2U.js";import{c as r,o}from"./DuBZZIW0.js";const c={};function s(t,n){return o(),r("hr")}const f=Object.assign(e(c,[["render",s]]),{__name:"ProseHr"});export{f as default};
