import{_ as e,c as r,o as c}from"./D5VEO_8d.js";const o={};function s(n,t){return c(),r("hr")}const a=Object.assign(e(o,[["render",s]]),{__name:"ProseHr"});export{a as default};
