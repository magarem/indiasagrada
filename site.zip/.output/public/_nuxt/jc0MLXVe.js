var r={};function e(t="pui_id_"){return Object.hasOwn(r,t)||(r[t]=0),r[t]++,`${t}${r[t]}`}export{e as s};
